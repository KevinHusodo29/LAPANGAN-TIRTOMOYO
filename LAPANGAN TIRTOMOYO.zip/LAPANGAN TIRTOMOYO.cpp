#include <stdio.h>//Pustaka input/output standar, digunakan untuk melakukan operasi input dan output dasar.
#include <stdlib.h>//Pustaka standar, digunakan untuk menjalankan fungsi umum seperti alokasi memori dan konversi string.
#include <locale.h>//Pustaka pelokalan, digunakan untuk mengatur lokal program dan pengodean karakter.
#include <string.h>//Pustaka string, digunakan untuk memanipulasi string.
#include <windows.h>//pustaka operasi tingkat sistem seperti membuat jendela dan menangani input/output.
#include <conio.h>//Pustaka input/output konsol, digunakan untuk melakukan operasi input/output tingkat rendah di konsol.

struct data
{
    int no;// variabel integer bernama "no"
    char namalapangan[101];//karakter array bernama "namalapangan" dengan ukuran 101
    char namapemesan[101];//karakter array bernama "namapemesan" dengan ukuran 101
    char tanggal[101];//karakter array bernama "tanggal" dengan ukuran 101
    char jenisLapangan[51];//karakter array bernama "jenisLapangan" dengan ukuran 101
    int dd, mm, yy;//tiga variabel bilangan bulat yang disebut "dd", "mm", dan "yy"
    long int harga;//variabel integer panjang bernama "harga"
    int terpesan;//sebuah variabel integer bernama "terpesan"
    int jumlah;//sebuah variabel integer bernama "jumlah"
}lapangan, simpan;//aris ini membuat dua variabel "lapangan" dan "simpan" dari struktur "data".

struct temp//Baris ini membuat struktur yang disebut "temp" yang berisi beberapa anggota atau variabel
{
    char namalapangan[101][101];//karakter array 2D bernama "namalapangan" dengan dimensi 101x101
    char namapemesan[101][101];//karakter array 2D bernama "namapemesan" dengan dimensi 101x101
    char jenislapangan[101][101];//karakter array 2D bernama "jenislapangan" dengan dimensi 101x101
    long int harga[101];//array bilangan bulat bernama "harga" dengan ukuran 101
    int terpesan[101];//array bilangan bulat bernama "terpesan" dengan ukuran 101
}tempp;//baris ini membuat variabel "tempp" dari struktur "temp".

//PROGRAM LOADING
//// Fungsi yang disebut "LOADING" ini menampilkan pesan yang menunjukkan bahwa program sedang memuat 
//dan menganimasikan bilah progres dengan mencetak serangkaian karakter.
void loading(){
	printf("\n\n\n\n\n\n\n");//Baris kode ini mencetak beberapa baris baru untuk membuat spasi sebelum memuat pesan
    printf("\n\n\n\t\t\t\t\t Loading......");//Baris kode ini menampilkan pesan "Loading..."
    printf("\n\n");//Baris kode ini mencetak baris baru
    printf( "\t\t\t\t\t");//Baris kode ini mencetak tab
    for (int i=0; i<= 30; i++){//Perulangan for ini berulang 30 kali dan mencetak serangkaian karakter
        printf("%c", 175);//Baris kode ini mencetak karakter dengan nilai ASCII 175, 
		                  //yang merupakan karakter blok yang sering digunakan untuk membuat bilah progres
        Sleep(45);//Baris kode ini menyebabkan program berhenti selama 45 milidetik 
		          //sebelum mencetak karakter berikutnya, membuat efek animasi
    }
    printf ("\n\n\t\t\t\t\t TEKAN ENTER UNTUK LOGIN");//Baris kode ini mencetak pesan memberi tahu pengguna untuk menekan enter untuk masuk
    system ("pause>0");//Baris kode ini menyebabkan program berhenti dan menunggu pengguna menekan enter
    system ("cls");//Baris kode ini membersihkan layar konsol
}

//PROGRAM GOTOXY
// Fungsi yang disebut "gotoxy" ini memungkinkan program untuk memindahkan kursor ke lokasi tertentu di layar konsol.
void gotoxy(int x,int y){
	COORD coord = {0,0};//// Baris kode ini membuat variabel "coord" bertipe COORD dengan nilai awal x, y
	coord.X = x;//Baris kode ini menetapkan nilai x ke anggota X dari coord
	coord.Y = y;//Baris kode ini memberikan nilai y ke anggota Y dari coors
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
	//Baris kode ini mengatur posisi kursor ke koordinat yang ditentukan oleh coord
}

//PROGRAM LOGIN
// Fungsi yang disebut "LOGIN" ini digunakan untuk menangani proses login program.
void login(){
    	char username[10], password[8];//Baris kode ini membuat dua karakter array yang dipanggil "username" dan "password" dengan ukuran masing-masing 10 dan 8
    	int ulang = 0;//// Baris kode ini membuat variabel integer bernama "ulang" dengan nilai awal 0
	    for(int j=0; j<3; j++){// Perulangan for ini berulang tiga kali dan meminta pengguna untuk memasukkan nama pengguna dan kata sandi
	    printf("\t\t\t\t\t________________________________\n");// Baris kode ini mencetak satu baris karakter
        printf("\n");// Baris kode ini mencetak baris baru
        printf("\t\t\t\t========   Lapangan Badminton Tirtomoyo   ========\n");// Baris kode ini mencetak pesan
        printf("\t\t\t\t\t________________________________\n");//Baris kode ini mencetak satu baris karakter
        printf("\n");//Baris kode ini mencetak baris baru
        printf("\n");//Baris kode ini mencetak baris baru
        printf("Username: ");// Baris kode ini mencetak pesan "Username:"
        scanf ( "%s", &username); // Baris kode ini membaca masukan pengguna untuk variabel "Username".
        printf("\n");//Baris kode ini mencetak baris baru
        printf("Password: ");//Baris kode ini mencetak pesan "Password:"
        fflush(stdin);//Baris kode ini menyiram buffer input
            char ch;//Baris kode ini membuat variabel karakter yang disebut "ch"
        int i=0;//Baris kode ini membuat variabel integer bernama "i" dengan nilai awal 0
        int x=10;//Baris kode ini membuat variabel integer bernama "x" dengan nilai awal 10
        int y=8;//Baris kode ini membuat variabel integer bernama "y" dengan nilai awal 8
        while((ch = (char) _getch()) != '\r'){//Loop while ini membaca input pengguna untuk variabel "kata sandi", satu karakter dalam satu waktu.
    	if (ch == 8){//Jika pengguna menekan tombol backspace
    		password[i] = '\0';//Baris kode ini menyetel elemen array kata sandi saat ini ke null
    		gotoxy(x-1,y);//Baris kode ini memanggil fungsi gotoxy() dan memindahkan kursor ke kiri sebanyak satu karakter	
    		printf(" ");//Baris kode ini mencetak spasi
    		x--;//baris kodenya mengurangi nilai x dengan 1
    		i--;//baris kodenya mengurangi nilai i dengan 1	
    		gotoxy(x,y);//Baris kode ini memanggil fungsi gotoxy() dan memindahkan kursor ke posisi x dan y saat ini
		}
	
		else{
			password[i]=ch;//Baris kode ini menetapkan karakter input saat ini ke elemen saat ini dari array kata sandi
			gotoxy(x,y);//Baris kode ini memanggil fungsi gotoxy() dan memindahkan kursor ke posisi x dan y saat ini
			printf("*");//baris kode ini mencetak tanda bintang
			x++;//baris kodenya mengurangi nilai x dengan 1
			i++;//baris kodenya mengurangi nilai i dengan 1	
		}
	}
        if ((strcmp(username,"kevin")==0)&&(strcmp(password,"husodo")==0)) {
        	//Pernyataan if ini memeriksa apakah input pengguna untuk nama pengguna dan kata sandi cocok
			//dengan nilai "kevin" dan "husodo" yang telah ditentukan sebelumnya
        	printf("\n\n\n\n\n\n\t\t\t\t\t\t AKSES DITERIMA...!!");//Baris kode ini mencetak pesan yang menunjukkan bahwa pengguna telah diberikan akses
        	Sleep(1400);//Baris kode ini menyebabkan program terhenti selama 1400 milidetik
        	break;//Baris kode ini keluar dari for loop
        } else {
        	ulang++;//Baris kode ini menambah nilai ulang sebesar 1
        	if(ulang != 3){//Pernyataan if ini memeriksa apakah pengguna mencoba masuk kurang dari 3 kali
            printf("\n\n AKSES DITOLAK.");// Baris kode ini mencetak pesan "AKSES DITOLAK."
            Sleep(1400);//Baris kode ini menyebabkan program terhenti selama 1400 milidetik
             system ("pause>0");//Baris kode ini menyebabkan program berhenti dan menunggu pengguna menekan enter
        }
            else if(ulang == 3){//Pernyataan if else memeriksa apakah pengguna telah mencoba masuk 3 kali
            	printf("\n\n AKSES KELUAR.\n");// Baris kode ini mencetak pesan "AKSES KELUAR."
            	Sleep(1400);//Baris kode ini menyebabkan program terhenti selama 1400 milidetik
            	exit(0);// Baris kode ini mengakhiri program
			}
        }
        system("cls");//Baris kode ini membersihkan layar konsol
    }
}



// PROGRAM LAPORAN
int temp;
char tempChar[101];
int tempT;


void terlaris(){
    FILE *fp, *fj;//Baris kode ini membuat dua penunjuk file yang disebut "fp" dan "fj"
    int c1=0,c2=0, temp;//Baris kode ini membuat tiga variabel bilangan bulat yang disebut "c1", "c2" dan "temp" dengan nilai awal 0
    int arrayM1[101];//Baris kode ini membuat array bilangan bulat yang disebut "arrayM1" dengan ukuran 101

    fp = fopen("datalapangan.txt", "r");// Baris kode ini membuka file "datalapangan.txt" dalam mode baca dan menugaskannya ke penunjuk file "fp"
    while(fread(&lapangan, sizeof(struct data), 1, fp))//while loop ini membaca data pada file "datalapangan.txt" 
	//menggunakan pointer file "fp" dan struct data "lapangan"
    {
        strcpy(tempp.namalapangan[c1], lapangan.namalapangan);//Baris kode ini menyalin nama bidang dari data struct "lapangan" ke struct temp "tempp"
        tempp.terpesan[c1] = lapangan.terpesan;//Baris kode ini menyalin jumlah jam yang dipesan dari data struct "lapangan" ke struct temp "tempp"
        c1++;//Baris kode ini menambah nilai "c1" sebesar 1
    }

    for(int i=0; i<c1; i++)//Perulangan for ini digunakan untuk mengurutkan data dalam urutan menurun berdasarkan jumlah jam yang dipesan
    {
        for(int j=0; j<c1; j++)//Loop for ini digunakan untuk membandingkan nilai jumlah jam yang dipesan
        {
            if(tempp.terpesan[j] < tempp.terpesan[i])// Pernyataan if ini memeriksa apakah nilai jumlah jam yang dipesan pada posisi ke-j lebih kecil dari pada posisi ke-i
            {          
                temp = tempp.terpesan[i];//tukar nilai tempo.booked[i] dengan tempo.booked[j] dan simpan nilai temporer dalam variabel temp.
                tempp.terpesan[i] = tempp.terpesan[j];
                tempp.terpesan[j] = temp;

                temp = tempp.harga[i];//menukar nilai dari tempp.harga[i] dengan tempp.harga[j] dan menyimpan nilai sementara pada variabel temp.
                tempp.harga[i] = tempp.harga[j];
                tempp.harga[j] = temp;

                strcpy(tempChar, tempp.namalapangan[i]);//menukar nama dari tempp.namalapangan[i] dengan tempp.namalapangan[j] dan menyimpan nilai sementara pada variabel tempChar.
                strcpy(tempp.namalapangan[i], tempp.namalapangan[j]);
                strcpy(tempp.namalapangan[j], tempChar);

                strcpy(tempChar, tempp.jenislapangan[i]);//menukar jenis dari tempp.jenislapangan[i] dengan tempp.jenislapangan[j] dan menyimpan nilai sementara pada variabel tempChar.
                strcpy(tempp.jenislapangan[i], tempp.jenislapangan[j]);
                strcpy(tempp.jenislapangan[j], tempChar);
            }
        }
    }
	//Menampilkan judul laporan lapangan terlaris dan garis pembatas
    printf("\n--------------------------------------------------");
    printf("\n      Laporan berdasarkan lapangan terlaris     \n");
    printf("--------------------------------------------------\n");
    int c=0;
    for(int i=0; i<c1; i++)//Menggunakan perulangan untuk menampilkan nama lapangan, jumlah pemesanan, dan harga dari data yang sudah diurutkan
    {
        printf("%d. %-20s Terpesan sebanyak %d jam\n", i+1, tempp.namalapangan[i], tempp.terpesan[i]);
    }

    fclose(fp);//Fungsi fclose digunakan untuk menutup file yang telah dibuka sebelumnya
    printf("\n");//Menampilkan baris kosong setelah selesai menampilkan lapora
}

void tanggalTransaksi(){//fungsi tanggalTransaksi() yang digunakan untuk menampilkan laporan pemesanan lapangan berdasarkan tanggal.
    FILE *fp, *fb;
    int pilih,dd,mm,yy;
    long int total=0;
	int c;

    fp = fopen("datapemesananlapangan.txt", "r");//Fungsi ini membuka file "datapemesananlapangan.txt" dengan mode "r" (baca) dan mengatur lokale untuk format numerik.
    setlocale(LC_NUMERIC, "");
	//fungsi ini menampilkan menu untuk memilih jenis laporan yang akan ditampilkan (harian, bulanan, atau tahunan) dan meminta input pilihan dari pengguna.
    printf("\nLihat laporan pemesanan berdasarkan : \n");
    printf("[1] Harian\n");
    printf("[2] Bulan\n");
    printf("[3] Tahunan\n");
    printf("Pilih : "); scanf("%d", &pilih);
    switch (pilih)// fungsi ini mengeksekusi perintah berdasarkan pilihan yang dipilih oleh pengguna dengan menggunakan switch-case statement.
    {
    case 1://Pada case 1, fungsi meminta input tanggal dari pengguna, kemudian menampilkan laporan pemesanan berdasarkan tanggal yang dipilih.
		  //Fungsi mencetak data yang sesuai dengan tanggal yang dipilih dari file "datapemesananlapangan.txt" dan menghitung total transaksi.
        printf("\nMasukkan Tanggal, Bulan, Tahun (dd/mm/yyyy) : "); scanf("%d/%d/%d", &dd,&mm,&yy);
        printf("\n-------------------------------------------------------------------------------------------------------------------------------------------------------");
        printf("\n                         Laporan pemesanan berdasarkan tanggal %d/%d/%d       \n", dd, mm, yy);
        printf("-------------------------------------------------------------------------------------------------------------------------------------------------------");
        
        printf("\nTanggal Pemesan   Nama Pemesan       Nama Lapangan           Tanggal Lapangan      Jenis Lapangan   Jumlah Jam   Jumlah Harga      Total Pembayaran\n");
        while(fread(&simpan, sizeof(struct data), 1, fp))
        {
            if(simpan.dd == dd && simpan.mm == mm && simpan.yy == yy)
            {
              printf("%d/%d/%-13d %-18s %-25s %-22s %-16s %-8d %-20ld %ld\n", simpan.dd, simpan.mm, simpan.yy, simpan.namapemesan, simpan.namalapangan, simpan.tanggal, simpan.jenisLapangan, simpan.jumlah, simpan.harga, simpan.harga*simpan.jumlah);
              total += (simpan.harga*simpan.jumlah);
            }
        }
        printf("-------------------------------------------------------------------------------------------------------------------------------------------------------\n");
        printf("Total Transaksi : %ld\n", total);
        printf("\n");
        fclose(fp);
        break;
    case 2://Pada case 2, fungsi meminta input bulan dan tahun dari pengguna, kemudian menampilkan laporan pemesanan berdasarkan bulan dan tahun yang dipilih.
    	  //Fungsi mencetak data yang sesuai dengan bulan dan tahun yang dipilih dari file "datapemesananlapangan.txt" dan menghitung total transaksi.
        printf("\nMasukkan Bulan, Tahun (mm/yyyy) : "); scanf("%d/%d", &mm,&yy);
        printf("\n-------------------------------------------------------------------------------------------------------------------------------------------------------");
        printf("\n                         Laporan pemesanan berdasarkan tanggal %d %d      \n", mm, yy);
        printf("-------------------------------------------------------------------------------------------------------------------------------------------------------");
        
        
        printf("\nTanggal Pemesan   Nama Pemesan       Nama Lapangan           Tanggal Lapangan      Jenis Lapangan   Jumlah Jam   Jumlah Harga      Total Pembayaran\n");
        while(fread(&simpan, sizeof(struct data), 1, fp))
        {
            if(simpan.mm == mm && simpan.yy == yy)
            {
                printf("%d/%d/%-13d %-18s %-25s %-22s %-16s %-8d %-20ld %ld\n", simpan.dd, simpan.mm, simpan.yy, simpan.namapemesan, simpan.namalapangan, simpan.tanggal, simpan.jenisLapangan, simpan.jumlah, simpan.harga, simpan.harga*simpan.jumlah);
                total += (simpan.harga*simpan.jumlah);
            }
        }
        printf("-------------------------------------------------------------------------------------------------------------------------------------------------------\n");
        printf("Total Transaksi : %ld\n", total);                                                                                             
        fclose(fp);
        break;
    case 3://Pada case 3, fungsi meminta input tahun dari pengguna, kemudian menampilkan laporan pemesanan berdasarkan tahun yang dipilih. 
    	  //Fungsi mencetak data yang sesuai dengan tahun yang dipilih dari file "datapemesananlapangan.txt" dan menghitung total transaksi.
        printf("\nMasukkan Tahun (yyyy) : "); scanf("%d", &yy);
        printf("\n-------------------------------------------------------------------------------------------------------------------------------------------------------");
        printf("\n                                         Laporan pemesanan berdasarkan Tahun %d       \n", yy);
        printf("-------------------------------------------------------------------------------------------------------------------------------------------------------");
        
        printf("\nTanggal Pemesan   Nama Pemesan       Nama Lapangan           Tanggal Lapangan      Jenis Lapangan   Jumlah Jam   Jumlah Harga      Total Pembayaran\n");
        while(fread(&simpan, sizeof(struct data), 1, fp))
        {
            c++;
            if(simpan.yy == yy)
            {
                printf("%d/%d/%-13d %-18s %-25s %-22s %-16s %-8d %-20ld %ld\n", simpan.dd, simpan.mm, simpan.yy, simpan.namapemesan, simpan.namalapangan, simpan.tanggal, simpan.jenisLapangan, simpan.jumlah, simpan.harga, simpan.harga*simpan.jumlah);
                total += (simpan.harga*simpan.jumlah);
            }
        }
        printf("-------------------------------------------------------------------------------------------------------------------------------------------------------\n");
        printf("Total Transaksi : %ld\n", total);
        printf("\n");
        fclose(fp);//Pada setiap case, fungsi menutup file yang digunakan dan menghentikan eksekusi case dengan break.
        break;
    
    default:
        break;
    }
}

void laporan(){//fungsi laporan() yang digunakan untuk menampilkan menu utama program laporan pemesanan lapanga
    int pilih;
	//Fungsi ini menampilkan pesan pembuka dan meminta input pilihan dari pengguna, 
	//yang dapat berupa laporan berdasarkan tanggal transaksi, lapangan terlaris, atau keluar dari program.
    printf("\n----------------------------------------\n");
    printf("     PROGRAM LAPORAN PEMESANAN LAPANGAN     ");
    printf("\n----------------------------------------\n");
    do
    {
       printf("Anda ingin mencetak laporan bedasarkan : \n");
       printf("\n[1] Tanggal Transaksi");
       printf("\n[2] Lapangan Terlaris");
       printf("\n[3] Keluar\n");

       printf("\nMasukkan pilihan : "); scanf("%d", &pilih);
       switch (pilih)//Fungsi ini mengeksekusi perintah berdasarkan pilihan yang dipilih oleh pengguna dengan menggunakan switch-case statement.
       {
       case 1:// Pada case 1, fungsi memanggil fungsi tanggalTransaksi() untuk menampilkan laporan berdasarkan tanggal transaksi.
           tanggalTransaksi();
           break;
       case 2://Pada case 2, fungsi memanggil fungsi terlaris() untuk menampilkan laporan lapangan terlaris.
           terlaris();
           break;
       
       default://Pada case 3, fungsi menghentikan eksekusi program.
           break;
       }
    } while (pilih != 3);//Fungsi ini menggunakan do-while loop untuk memungkinkan pengguna untuk kembali ke menu utama setelah mengeksekusi perintah.
    
}

// PROGRAM TRANSAKSI LAPANGAN
void strukdata(){//Ini adalah fungsi strukdata() yang digunakan untuk menampilkan struk pemesanan lapangan
    char yes[6];

    setlocale(LC_NUMERIC, "");//Fungsi ini menampilkan pesan pembuka dan mengatur lokale untuk format numerik.
	//Kemudian, fungsi ini mencetak informasi pemesanan lapangan seperti nomor struk, 
	//nama pemesan, nama lapangan, tanggal lapangan, jenis lapangan, jumlah jam, harga, dan total pembayaran.
    printf("\n=======================================\n");
    printf("       STRUK PEMESANAN LAPANGAN            ");
    printf("\n=======================================\n");
    printf("No.Struk      : %d%d%d-%d\n", simpan.yy, simpan.mm, simpan.dd, lapangan.terpesan);
//Fungsi ini juga mencetak informasi tanggal dan lokasi pemesanan lapangan serta menanyakan kepada pengguna apakah ingin melanjutkan atau tidak.
    printf("\n---------- Identitas Pembeli ----------\n");
    printf("Nama Pemesan  : %s\n", simpan.namapemesan);
    printf("\n------------ Detail Lapangan -------------\n");
    printf("Nama Lapangan      : %s\n", simpan.namalapangan);
    printf("Tanggal Lapangan   : %s\n", simpan.tanggal);
    printf("Jenis Lapangan     : %s\n", simpan.jenisLapangan);
    printf("Jumlah Jam         : %d\n", simpan.jumlah);
    printf("Harga              : %d\n", simpan.harga);
    printf("\nTotal Pembayaran : %d\n", simpan.harga*simpan.jumlah);
    printf("\n                    Malang, %d/%d/%d\n\n", simpan.dd, simpan.mm, simpan.yy);
    printf("\n     Badminton Tirtomoyo               \n");
    printf("=======================================\n");
    printf("\nLanjut? (y/n) : "); scanf("%s",yes); 
    //Fungsi ini menggunakan variable struct simpan dan lapangan yang diharapkan sudah diisi sebelum fungsi ini dijalankan.
}

void updateterpesan(int id){
	//Fungsi ini digunakan untuk mengupdate informasi field tertentu dalam file bernama "datalapangan.txt".
    FILE *fp, *fp1;
    int found = 0;
	//Deklarasikan dua pointer file "fp" dan "fp1" dan variabel integer "ditemukan" dan inisialisasi ke 0.
    fp = fopen("datalapangan.txt", "r");
    fp1 = fopen("temp.txt", "w");//Buka file "temp.txt" dalam mode tulis dan tetapkan penunjuk file ke "fp1".
    while(fread(&lapangan, sizeof(struct data), 1, fp))//Baca data di "datalapangan.txt" menggunakan fungsi fread() dan while loop.
    {
        if(id == lapangan.no)//Bandingkan id yang diteruskan sebagai argumen dengan id dari setiap bidang.
        {
        	// jika ditemukan kecocokan, atur ditemukan menjadi 1 dan tambah nilai kolom "terpesan" dengan nilai "simpan.jumlah"
            found = 1;
            fflush(stdin);
            lapangan.terpesan+=simpan.jumlah;
        }
        fwrite(&lapangan, sizeof(struct data), 1, fp1);//tulis bidang yang diperbarui ke file sementara
    }
    // Tutup kedua file
    fclose(fp);
    fclose(fp1);
    if(found)//Jika ditemukan kecocokan, fungsi kemudian membuka file sementara dalam mode baca dan "datalapangan.txt"
    {
        fp1 = fopen("temp.txt", "r");
        fp = fopen("datalapangan.txt", "w");

        while(fread(&lapangan, sizeof(struct data), 1, fp1))//salin isi file sementara kembali ke "datalapangan.txt"
        {
            fwrite(&lapangan, sizeof(struct data), 1, fp);
        }
        // Tutup kedua file
        fclose(fp1);
        fclose(fp);
    }
    else//Jika tidak ditemukan kecocokan, ini mencetak pesan yang menunjukkan bahwa id tidak ditemukan.
        printf("\nID Lapangan tidak ditemukan\n");
}

void transaksi(){
	//mendeklarasikan tiga variabel, pilih, ya dan x sebagai bilangan bulat.
    int pilih;
    char yes[3];
    int x;
    FILE *fp, *finformasi, *pemesanan;//mendeklarasikan tiga file pointer, fp, informasi, dan pemesanan.
	//membuka file "datalapangan.txt" dalam mode baca dan menugaskan penunjuk file ke fp.
    fp = fopen("datalapangan.txt", "r");
	//mencetak teks di antara tanda kutip pada baris terpisah di konsol.
    printf("\n===============================\n");
    printf("     Program Transaksi Lapangan    ");
    printf("\n===============================\n");
    do//menggunakn perulangan do-while
    {
        while(fread(&lapangan, sizeof(struct data), 1, fp))//memulai while loop yang membaca isi file yang ditunjuk oleh 
		//fp ke dalam struct "lapangan". Loop berlanjut selama ada data yang akan dibaca.
        {
        	//mencetak nilai field "no", "nama lapangan", dan "tanggal" dari struktur "lapangan" dalam satu baris, dengan format tertentu.
            printf("[%d] %-20s%s\n", lapangan.no, lapangan.namalapangan, lapangan.tanggal);
        }
		//mencetak teks di antara tanda kutip di konsol dan menunggu input pengguna. Input tersebut kemudian disimpan dalam variabel "yes".
        printf("\nApakah customer ingin memesan (y/t) : "); scanf("%s", yes);
        if(yes[0] == 'y')//memeriksa apakah karakter pertama dari input yang disimpan di "yes" adalah 'y'. Jika ya, kode di dalam pernyataan if akan dijalankan.
        {
            printf("\nMasukkan nama pemesan                : "); scanf("\n%[^\n]", simpan.namapemesan);
            printf("\nNo lapangan yang ingin dipilih : "); scanf("%d", &x);
            fp = fopen("datalapangan.txt", "r");
            while(fread(&lapangan, sizeof(struct data), 1, fp))
            {
                if(x == lapangan.no)//memeriksa apakah nilai "x" sama dengan nilai "lapangan.no". Jika ya, kode di dalam pernyataan if akan dijalankan.
                {
                    printf("\nPilih Nama Lapangan : \n");
                    printf("[1] Badminton : Rp.40.000,00\n");
                    printf("[2] Futsal : Rp.160.000,00\n");

                    printf("\nMasukkan Pilihan Pemesan : "); scanf("%d", &pilih);
                    switch (pilih)//memulai pernyataan yang memeriksa nilai variabel "pilih".
                    {
                    case 1://memulai perintah yang akan dijalankan jika nilai "pilih" adalah 1.
                        printf("Berapa jam yang dipesan   : "); scanf("%d", &simpan.jumlah);//mencetak teks di antara tanda kutip di konsol dan menunggu input pengguna.
						//Input tersebut kemudian disimpan dalam variabel “simpan.jumlah”.
                        finformasi = fopen("datapemesananlapangan.txt", "a");//membuka file "datapemesananlapangan.txt" dalam mode append dan menugaskan pointer file ke informasi.
                        simpan.harga = 40000;//menugaskan 40000 ke variabel "simpan.harga".
                        strcpy(simpan.namalapangan, lapangan.namalapangan);//salin isi "lapangan.namalapangan" ke "simpan.namalapangan".
                        strcpy(simpan.tanggal, lapangan.tanggal);//menyalin isi "lapangan.tanggal" menjadi "simpan.tanggal".
                        strcpy(simpan.jenisLapangan, "Badminton");//salin string "Badminton" ke "simpan.jenisLapangan".
                        printf("Masukkan tanggal pemesan (dd/mm/yyyy): "); scanf("%d/%d/%d", &simpan.dd, &simpan.mm, &simpan.yy);//mencetak teks di antara tanda kutip 
						//di konsol dan menunggu input pengguna dalam format "dd/mm/yyyy".
                        strukdata();//memanggil fungsi bernama "strukdata()".
                        updateterpesan(x);//memanggil fungsi bernama "updateterpesan()" dan meneruskan "x" sebagai argumen.
                        fwrite(&simpan, sizeof(struct data), 8, finformasi);//menulis isi dari struct "simpan" ke file yang ditunjuk oleh data.
                        pemesanan = fopen("Pemesanan.txt", "a");//membuka file "Pemesanan.txt" dalam mode append dan menugaskan pointer file ke pemesanan.
                        //menulis nilai variabel dari struct "simpan" dalam format tertentu ke file yang ditunjuk oleh pemesanan.
                        fprintf(pemesanan, "%d/%d/%d, %s, %s, %s, %s, %d, %ld, %ld\n", simpan.dd, simpan.mm, simpan.yy, simpan.namapemesan, simpan.namalapangan, simpan.tanggal, simpan.jenisLapangan, simpan.jumlah, simpan.harga, simpan.harga*simpan.jumlah);
                        break;
                    case 2:
                        printf("Berapa jam yang dipesan   : "); scanf("%d", &simpan.jumlah);
                        finformasi = fopen("datapemesananlapangan.txt", "a");
                        simpan.harga = 160000;//menugaskan 1600000 ke variabel "simpan.harga".
                        strcpy(simpan.namalapangan, lapangan.namalapangan);
                        strcpy(simpan.tanggal, lapangan.tanggal);
                        strcpy(simpan.jenisLapangan, "Futsal");
                        printf("Masukkan tanggal pemesan (dd/mm/yyyy): "); scanf("%d/%d/%d", &simpan.dd, &simpan.mm, &simpan.yy);
                        strukdata();
                        updateterpesan(x);
                        fwrite(&simpan, sizeof(struct data), 8, finformasi);
                        pemesanan = fopen("pemesanan.txt", "a");
                        fprintf(pemesanan, "%d/%d/%d, %s, %s, %s, %s, %d, %ld, %ld\n", simpan.dd, simpan.mm, simpan.yy, simpan.namapemesan, simpan.namalapangan, simpan.tanggal, simpan.jenisLapangan, simpan.jumlah, simpan.harga, simpan.harga*simpan.jumlah);
                        
                        break;
                    default:
                        break;
                    }
                }
            }
        }
        else break;//dieksekusi jika kondisi pada pernyataan if sebelumnya tidak terpenuhi, maka akan keluar dari perulangan do-while.
        fclose(fp);//menutup file yang ditunjuk oleh fp.
        fclose(finformasi);//menutup file yang ditunjuk oleh finformasi.
        fclose(pemesanan);//menutup file yang ditunjuk oleh pemesanan.
    } while (pilih!=0);//akhir perulangan do-while, perulangan akan terus dijalankan selama nilai "pilih" tidak sama dengan 0.
}



// PROGRAM INPUTAN 
void Jadwallapangan(){//fungsi yang tidak mengembalikan nilai apapun.
    FILE *fp;//mendeklarasikan pointer file bernama "fp".

    fp = fopen("datalapangan.txt", "r");//membuka file "datalapangan.txt" dalam mode baca dan menugaskan
    //mencetak teks di antara tanda kutip di konsol.
    printf("\n---------------------------------------\n");
    printf("       Lapangan yang Tersedia              ");
    printf("\n---------------------------------------\n");
    while(fread(&lapangan, sizeof(struct data),1,fp))
    //memulai perulangan while yang membaca isi file "datalapangan.txt" dan menyimpannya di struct "lapangan". 
	//Perulangan terus dijalankan selama masih ada data untuk dibaca di dalam file.
    {
    	//mencetak nilai variabel di struct "lapangan" dalam format tertentu di konsol.
        printf("[%d] %-20s%s\n", lapangan.no, lapangan.namalapangan, lapangan.tanggal);
    }
    printf("---------------------------------------\n\n");

    fclose(fp);//menutup file yang ditunjuk oleh "fp".
}

void Tambahlapangan(){
    FILE *fp;
    int n;
	//membuka file "datalapangan.txt" dalam mode append dan menugaskan penunjuk file ke "fp".
    fp = fopen("datalapangan.txt", "a");
    //meminta memasukkan jumlah data yang ingin mereka tambahkan dan menyimpannya dalam variabel "n".
    printf("Berapa data yang ingin anda tambahkan : "); scanf("%d", &n);
    for(int i=0; i<n; i++)//memulai perulangan for yang akan mengeksekusi "n" beberapa kali.memulai perulangan for yang akan mengeksekusi "n" beberapa kali.
    {
        printf("Nomor Lapangan   : "); scanf("%d", &lapangan.no);
        printf("Nama Lapangan    : "); scanf("\n%[^\n]s", lapangan.namalapangan);
        printf("Tanggal Lapangan : "); scanf("\n%[^\n]s", lapangan.tanggal);
        printf("Terpesan         : "); scanf("%d", &lapangan.terpesan);
        fwrite(&lapangan, sizeof(struct data), 1, fp);//menulis isi dari struct "lapangan" ke file yang ditunjuk oleh "fp".
    }
    fclose(fp);//menutup file yang ditunjuk oleh "fp".
    printf("\n");
}

void Updatelapangan(){
    FILE *fp, *fp1;//mendeklarasikan dua pointer file bernama "fp" dan "fp1".
    int x, found = 0;

    fp = fopen("datalapangan.txt", "r");//membuka file "datalapangan.txt" dalam mode baca dan menugaskan penunjuk file ke "fp".
    fp1 = fopen("temp.txt", "w");//membuka file "temp.txt" dalam mode tulis dan menugaskan penunjuk file ke "fp1".

    printf("Masukkan nomor lapangan yang ingin diganti : ");
    scanf("%d", &x);
    while(fread(&lapangan, sizeof(struct data), 1, fp))//memulai perulangan while yang membaca isi file yang ditunjuk oleh "fp" ke dalam struct "lapangan". 
	//Perulangan berlanjut hingga akhir file tercapai.
    {
        if(x == lapangan.no)//Bandingkan id yang diteruskan sebagai argumen dengan id dari setiap bidang.
        {
            found = 1;
            printf("Masukkan nama lapangan baru     : "); scanf("\n%[^\n]s", lapangan.namalapangan);
            printf("Masukkan tanggal lapangan  baru : "); scanf("\n%[^\n]s", lapangan.tanggal);
        }
        fwrite(&lapangan, sizeof(struct data), 1, fp1);//menulis struct saat ini ke file "temp.txt".
    }
    //menutup kedua penunjuk file
    fclose(fp);
    fclose(fp1);
    if(found)//memeriksa apakah nomor yang dimasukkan ditemukan dalam file.
			//Jika sudah, buka "temp.txt" dalam mode baca dan "datalapangan.txt" dalam mode tulis, lalu salin isi "temp.txt" ke "datalapangan.txt".
    {
        fp1 = fopen("temp.txt", "r");
        fp = fopen("datalapangan.txt", "w");
		//memulai while loop yang membaca isi file yang ditunjuk oleh "fp" ke dalam struct "lapangan". 
		//Perulangan berlanjut hingga akhir file tercapai.
        while(fread(&lapangan, sizeof(struct data), 1, fp1))
        {
            fwrite(&lapangan, sizeof(struct data), 1, fp);
        }
        fclose(fp1);
        fclose(fp);
    }
    else//memberi tahu nomor yang dimasukkan tidak ditemukan dalam file dan pembaruan tidak dapat dilakukan
        printf("\nNo lapangan tidak ditemukan\n");
}
void Deletlapangan(){
    FILE *fp, *fp1;//mendeklarasikan dua pointer file bernama "fp" dan "fp1".
    int x, found = 0;

    fp = fopen("datalapangan.txt", "r");
    fp1 = fopen("temp.txt", "w");
	//menggunakan fungsi "printf" dan menyimpan input dalam variabel "x" menggunakan fungsi "scanf".
    printf("Masukkan nomor lapangan yang ingin dihapus : ");
    scanf("%d", &x);
    while(fread(&lapangan, sizeof(struct data), 1, fp))//menggunakan while loop untuk membaca isi file “datalapangan.txt” 
	//menggunakan fungsi “fread”. Perulangan berlanjut hingga akhir file tercapai.
    {
        if(x == lapangan.no)//if digunakan untuk memeriksa apakah nomor field yang dimasukkan oleh pengguna cocok dengan nomor field saat ini di dalam file.
        {
            found = 1;
        } else
            fwrite(&lapangan, sizeof(struct data), 1, fp1);
    }
    ////menutup kedua penunjuk file
    fclose(fp);
    fclose(fp1);
    if(found)////memeriksa apakah nomor yang dimasukkan ditemukan dalam file.
    {
        fp1 = fopen("temp.txt", "r");
        fp = fopen("datalapangan.txt", "w");

        while(fread(&lapangan, sizeof(struct data), 1, fp1))
        {
            fwrite(&lapangan, sizeof(struct data), 1, fp);
        }
        fclose(fp1);
        fclose(fp);
    }
    else////memberi tahu nomor yang dimasukkan tidak ditemukan dalam file dan pembaruan tidak dapat dilakukan
        printf("\nNo lapangan tidak ditemukan\n");
}

void programinputan(){//menampilkan menu pilihan yang berisi 4 pilihan yaitu :
    int pilih;

    printf("\n--------------------------------\n");
    printf("     Program Pendataan Lapangan     ");
    printf("\n--------------------------------\n");
    do
    {
        printf("[1] List Data Lapangan\n");//untuk menampilkan data lapangan yang tersedia.
        printf("[2] Tambah Lapangan\n");//menambahkan data lapangan baru.
        printf("[3] Update Lapangan\n");//mengupdate data lapangan yang sudah ada.
        printf("[4] Delete Lapangan\n");//menghapus data lapangan yang sudah ada.
        printf("[0] Keluar\n");//keluar dari program.

        printf("\nMasukan pilihan : "); scanf("%d", &pilih);
        switch (pilih)// setiap pilihan yang dipilih user, akan menjalankan fungsi yang sesuai dengan pilihan tersebut.
        {
        case 1:
            Jadwallapangan();
            break;

        case 2:
            Tambahlapangan();
            break;

        case 3:
            Updatelapangan();
            break;

        case 4:
            Deletlapangan();
            break;
        
        
        default:
            break;
        }
    //program akan kembali menampilkan menu pilihan selama pilihan yang dipilih bukan 0 (Keluar)
    } while (pilih!=0);
}

int main(int argc, char const *argv[])
{	
    int pilih;
	loading();
	login();
	//perulangan ini, digunakan sebuah variabel "pilih" yang digunakan untuk menyimpan input pilihan dari pengguna.     
    do
    {
        printf("\n================================\n");
        printf("   Lapangan Badminton Tirtomoyo   ");
        printf("\n================================\n");
        printf("Silahkan pilih program dibawah : \n");

        printf("[1] Pendataan Lapangan\n");
        printf("[2] Transaksi\n");
        printf("[3] Laporan\n");
        printf("[0] Keluar\n");

        printf("\nMasukan pilihan : "); scanf("%d", &pilih);
        switch (pilih)//menentukan aksi yang akan diambil sesuai dengan pilihan pengguna. 
        {
        case 1:
            programinputan();
            break;

        case 2:
            transaksi();
            break;

        case 3:
            laporan();
            break;
        
        default://Pada default case tidak dilakukan aksi apapun. 
            break;
        }
    } while (pilih!=0);//Perulangan akan berhenti jika pengguna memasukkan input 0.
    
    return 0;
}
